package com.cg.ibs.loanmgmt.bean;

public enum TransactionMode {
		ONLINE, CASH;
}
