package com.cg.ibs.loanmgmt.bean;

public enum ApplicantStatus {
	PENDING, APPROVED, DENIED;
}
